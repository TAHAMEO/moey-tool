"""Instagram Python SDK — async client for the Instagram Graph API.

Quick-start::

    from instagram import InstagramClient, AccountField

    async with InstagramClient(
        access_token="...",
        ig_user_id="17841405822304914",
    ) as client:
        user = await client.account.get_profile(
            fields=[AccountField.USERNAME, AccountField.FOLLOWERS_COUNT]
        )
        print(user.username, user.followers_count)
"""

__version__ = "0.1.0"

from instagram.client import InstagramClient
from instagram.exceptions import (
    InstagramAPIError,
    InstagramAuthError,
    InstagramConfigError,
    InstagramContainerError,
    InstagramNotFoundError,
    InstagramPermissionError,
    InstagramRateLimitError,
    InstagramSDKError,
    InstagramServerError,
)
from instagram.models import (
    AccountField,
    AccountInsightData,
    AccountInsightMetric,
    AccountInsightPeriod,
    BusinessDiscoveryUser,
    Comment,
    CommentListResponse,
    ContainerResponse,
    ContainerStatus,
    ContainerStatusResponse,
    CursorPaging,
    DemographicMetric,
    Hashtag,
    HashtagMediaResponse,
    InsightValue,
    InstagramBaseModel,
    InstagramError,
    Media,
    MediaInsightData,
    MediaInsightMetric,
    MediaListResponse,
    MediaProductType,
    MediaType,
    MentionedMedia,
    PagingCursors,
    PublishResponse,
    ReelInsightMetric,
    StoryInsightMetric,
    TaggedMediaResponse,
    User,
)

__all__ = [
    "AccountField",
    "AccountInsightData",
    "AccountInsightMetric",
    "AccountInsightPeriod",
    "BusinessDiscoveryUser",
    "Comment",
    "CommentListResponse",
    "ContainerResponse",
    "ContainerStatus",
    "ContainerStatusResponse",
    "CursorPaging",
    "DemographicMetric",
    "Hashtag",
    "HashtagMediaResponse",
    "InsightValue",
    "InstagramAPIError",
    "InstagramAuthError",
    "InstagramBaseModel",
    "InstagramClient",
    "InstagramConfigError",
    "InstagramContainerError",
    "InstagramError",
    "InstagramNotFoundError",
    "InstagramPermissionError",
    "InstagramRateLimitError",
    "InstagramSDKError",
    "InstagramServerError",
    "Media",
    "MediaInsightData",
    "MediaInsightMetric",
    "MediaListResponse",
    "MediaProductType",
    "MediaType",
    "MentionedMedia",
    "PagingCursors",
    "PublishResponse",
    "ReelInsightMetric",
    "StoryInsightMetric",
    "TaggedMediaResponse",
    "User",
]
