"""Account / user profile API namespace.

Provides access to the authenticated user's profile information and
business discovery of other public Business/Creator accounts.
"""

from __future__ import annotations

from instagram.apis.base import BaseAPI
from instagram.models.account import AccountField, BusinessDiscoveryUser, User


class AccountAPI(BaseAPI):
    """Read the authenticated user's profile and discover other public accounts.

    Example::

        user = await client.account.get_profile(
            fields=[AccountField.USERNAME, AccountField.FOLLOWERS_COUNT]
        )
        print(user.username, user.followers_count)
    """

    async def get_profile(
        self,
        fields: list[AccountField] | None = None,
    ) -> User:
        """Fetch the authenticated user's profile.

        Parameters
        ----------
        fields:
            Which profile fields to return.  Defaults to all available fields.

        Returns
        -------
        User
            Profile data with only the requested fields populated.
        """
        if fields is None:
            fields = list(AccountField)

        url = self._session.url(f"{self._session.ig_user_id}")
        params = {"fields": ",".join(fields)}
        data = await self._session.get(url, params=params)
        return User.model_validate(data)

    async def get_business_discovery(
        self,
        target_username: str,
        *,
        media_fields: str | None = None,
        media_limit: int | None = None,
    ) -> BusinessDiscoveryUser:
        """Look up a public Business or Creator account by username.

        Parameters
        ----------
        target_username:
            Instagram username (without ``@``) of the target account.
        media_fields:
            Comma-separated list of media fields to include in the nested
            ``media`` edge (e.g. ``"id,caption,media_type,like_count"``).
        media_limit:
            Maximum number of media items to include.

        Returns
        -------
        BusinessDiscoveryUser
            Public profile data for the target account.
        """
        inner_fields = (
            "username,name,biography,followers_count,follows_count,"
            "media_count,profile_picture_url,website,id"
        )

        if media_fields:
            media_clause = f",media{{{media_fields}"
            if media_limit is not None:
                media_clause = f",media.limit({media_limit}){{{media_fields}"
            inner_fields += media_clause + "}"

        fields = f"business_discovery.username({target_username}){{{inner_fields}}}"
        url = self._session.url(f"{self._session.ig_user_id}")
        params = {"fields": fields}
        data = await self._session.get(url, params=params)

        bd = data.get("business_discovery", {})
        return BusinessDiscoveryUser.model_validate(bd)
