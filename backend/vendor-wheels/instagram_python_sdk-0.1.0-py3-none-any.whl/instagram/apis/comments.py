"""Comments API namespace.

Provides methods to list, post, reply to, hide, and delete comments
on the authenticated user's media.
"""

from __future__ import annotations

from typing import Any

from instagram.apis.base import BaseAPI
from instagram.models.comments import Comment, CommentListResponse

# Default fields to request when listing comments.
_DEFAULT_COMMENT_FIELDS = "id,text,timestamp,username,like_count"


class CommentsAPI(BaseAPI):
    """Manage comments on the authenticated user's media.

    Example::

        comments = await client.comments.list_comments(
            media_id="17890455278604900",
        )
        for comment in comments.data:
            print(comment.username, comment.text)
    """

    async def list_comments(
        self,
        media_id: str,
        *,
        fields: str | None = None,
        after: str | None = None,
        limit: int | None = None,
    ) -> CommentListResponse:
        """List top-level comments on a media object.

        Parameters
        ----------
        media_id:
            Instagram media ID.
        fields:
            Comma-separated comment fields (defaults to common fields).
        after:
            Cursor for forward pagination.
        limit:
            Number of items per page.

        Returns
        -------
        CommentListResponse
            Paginated list of comments.
        """
        url = self._session.url(f"{media_id}/comments")
        params: dict[str, Any] = {
            "fields": fields or _DEFAULT_COMMENT_FIELDS,
        }
        if after is not None:
            params["after"] = after
        if limit is not None:
            params["limit"] = limit

        data = await self._session.get(url, params=params)
        return CommentListResponse.model_validate(data)

    async def get_comment(
        self,
        comment_id: str,
        *,
        fields: str | None = None,
    ) -> Comment:
        """Fetch a single comment by ID.

        Parameters
        ----------
        comment_id:
            Instagram comment ID.
        fields:
            Comma-separated comment fields.

        Returns
        -------
        Comment
            The requested comment.
        """
        url = self._session.url(comment_id)
        params = {"fields": fields or _DEFAULT_COMMENT_FIELDS}
        data = await self._session.get(url, params=params)
        return Comment.model_validate(data)

    async def get_replies(
        self,
        comment_id: str,
        *,
        fields: str | None = None,
        after: str | None = None,
        limit: int | None = None,
    ) -> CommentListResponse:
        """List replies to a comment.

        Parameters
        ----------
        comment_id:
            Instagram comment ID.
        fields:
            Comma-separated comment fields.
        after:
            Cursor for forward pagination.
        limit:
            Number of items per page.

        Returns
        -------
        CommentListResponse
            Paginated list of reply comments.
        """
        url = self._session.url(f"{comment_id}/replies")
        params: dict[str, Any] = {
            "fields": fields or _DEFAULT_COMMENT_FIELDS,
        }
        if after is not None:
            params["after"] = after
        if limit is not None:
            params["limit"] = limit

        data = await self._session.get(url, params=params)
        return CommentListResponse.model_validate(data)

    async def post_comment(
        self,
        media_id: str,
        message: str,
    ) -> Comment:
        """Post a new top-level comment on a media object.

        Parameters
        ----------
        media_id:
            Instagram media ID.
        message:
            Comment text.

        Returns
        -------
        Comment
            The newly created comment (contains ``id``).
        """
        url = self._session.url(f"{media_id}/comments")
        params = {"message": message}
        data = await self._session.post(url, params=params)
        return Comment.model_validate(data)

    async def reply_to_comment(
        self,
        comment_id: str,
        message: str,
    ) -> Comment:
        """Reply to an existing comment.

        Parameters
        ----------
        comment_id:
            Instagram comment ID to reply to.
        message:
            Reply text.

        Returns
        -------
        Comment
            The newly created reply (contains ``id``).
        """
        url = self._session.url(f"{comment_id}/replies")
        params = {"message": message}
        data = await self._session.post(url, params=params)
        return Comment.model_validate(data)

    async def hide_comment(
        self,
        comment_id: str,
        *,
        hide: bool = True,
    ) -> bool:
        """Hide or unhide a comment.

        Parameters
        ----------
        comment_id:
            Instagram comment ID.
        hide:
            ``True`` to hide, ``False`` to unhide.

        Returns
        -------
        bool
            ``True`` if the operation succeeded.
        """
        url = self._session.url(comment_id)
        params = {"hide": str(hide).lower()}
        data = await self._session.post(url, params=params)
        return bool(data.get("success", False))

    async def delete_comment(
        self,
        comment_id: str,
    ) -> bool:
        """Delete a comment on the authenticated user's media.

        Parameters
        ----------
        comment_id:
            Instagram comment ID.

        Returns
        -------
        bool
            ``True`` if the deletion succeeded.
        """
        url = self._session.url(comment_id)
        data = await self._session.delete(url)
        return bool(data.get("success", False))

    async def toggle_comments(
        self,
        media_id: str,
        *,
        enabled: bool,
    ) -> bool:
        """Enable or disable comments on a media object.

        Parameters
        ----------
        media_id:
            Instagram media ID.
        enabled:
            ``True`` to enable comments, ``False`` to disable.

        Returns
        -------
        bool
            ``True`` if the operation succeeded.
        """
        url = self._session.url(media_id)
        params = {"comment_enabled": str(enabled).lower()}
        data = await self._session.post(url, params=params)
        return bool(data.get("success", False))
