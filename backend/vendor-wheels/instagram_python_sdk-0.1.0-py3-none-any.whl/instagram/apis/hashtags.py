"""Hashtags API namespace.

Provides methods to search for hashtags and retrieve top/recent media
associated with a given hashtag.
"""

from __future__ import annotations

from typing import Any

from instagram.apis.base import BaseAPI
from instagram.models.hashtags import Hashtag, HashtagMediaResponse, HashtagSearchResponse
from instagram.models.media import Media

# Default fields returned for hashtag media queries.
_DEFAULT_HASHTAG_MEDIA_FIELDS = (
    "id,caption,media_type,media_url,permalink,timestamp,like_count,comments_count"
)


class HashtagsAPI(BaseAPI):
    """Search for hashtags and browse their top/recent media.

    Example::

        hashtag = await client.hashtags.search("photography")
        top = await client.hashtags.get_top_media(hashtag.id)
        for post in top.data:
            print(post.permalink, post.like_count)

    Note:
        Hashtag searches are limited to 30 unique queries per 7-day
        rolling window per account.
    """

    async def search(
        self,
        query: str,
    ) -> Hashtag:
        """Search for a hashtag and return its Instagram ID.

        Parameters
        ----------
        query:
            Hashtag text (without the ``#`` prefix).

        Returns
        -------
        Hashtag
            The hashtag with its ``id`` for use in top/recent media queries.

        Raises
        ------
        InstagramAPIError
            If the hashtag is not found or the rate limit is exceeded.
        """
        url = self._session.url("ig_hashtag_search")
        params = {
            "user_id": self._session.ig_user_id,
            "q": query,
        }
        data = await self._session.get(url, params=params)
        response = HashtagSearchResponse.model_validate(data)
        if not response.data:
            from instagram.exceptions import InstagramNotFoundError

            raise InstagramNotFoundError(
                code=803,
                error_type="IGApiException",
                message=f"Hashtag '{query}' not found.",
                fbtrace_id="",
                http_status=404,
            )
        return response.data[0]

    async def get_top_media(
        self,
        hashtag_id: str,
        *,
        fields: str | None = None,
    ) -> HashtagMediaResponse:
        """Get top (most popular) media for a hashtag.

        Parameters
        ----------
        hashtag_id:
            Hashtag node ID from :meth:`search`.
        fields:
            Comma-separated media fields.

        Returns
        -------
        HashtagMediaResponse
            List of top media for this hashtag.
        """
        url = self._session.url(f"{hashtag_id}/top_media")
        params: dict[str, Any] = {
            "user_id": self._session.ig_user_id,
            "fields": fields or _DEFAULT_HASHTAG_MEDIA_FIELDS,
        }
        data = await self._session.get(url, params=params)
        return HashtagMediaResponse.model_validate(data)

    async def get_recent_media(
        self,
        hashtag_id: str,
        *,
        fields: str | None = None,
    ) -> HashtagMediaResponse:
        """Get recent media for a hashtag.

        Parameters
        ----------
        hashtag_id:
            Hashtag node ID from :meth:`search`.
        fields:
            Comma-separated media fields.

        Returns
        -------
        HashtagMediaResponse
            List of recent media for this hashtag.
        """
        url = self._session.url(f"{hashtag_id}/recent_media")
        params: dict[str, Any] = {
            "user_id": self._session.ig_user_id,
            "fields": fields or _DEFAULT_HASHTAG_MEDIA_FIELDS,
        }
        data = await self._session.get(url, params=params)
        return HashtagMediaResponse.model_validate(data)

    async def get_hashtag_info(
        self,
        hashtag_id: str,
    ) -> Hashtag:
        """Fetch the name of a hashtag by its ID.

        Parameters
        ----------
        hashtag_id:
            Hashtag node ID.

        Returns
        -------
        Hashtag
            The hashtag with its ``id`` and ``name``.
        """
        url = self._session.url(hashtag_id)
        params = {"fields": "id,name"}
        data = await self._session.get(url, params=params)
        return Hashtag.model_validate(data)

    async def search_and_get_top_media(
        self,
        query: str,
        *,
        fields: str | None = None,
    ) -> tuple[Hashtag, list[Media]]:
        """Convenience: search a hashtag and immediately get its top media.

        Parameters
        ----------
        query:
            Hashtag text (without the ``#`` prefix).
        fields:
            Comma-separated media fields.

        Returns
        -------
        tuple[Hashtag, list[Media]]
            The hashtag object and the list of top media.
        """
        hashtag = await self.search(query)
        response = await self.get_top_media(hashtag.id, fields=fields)
        return hashtag, response.data
