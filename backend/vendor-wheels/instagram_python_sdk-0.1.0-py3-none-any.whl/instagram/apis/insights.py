"""Insights / analytics API namespace.

Provides access to account-level and media-level performance metrics
via the Instagram Graph API insights endpoints.
"""

from __future__ import annotations

from typing import Any

from instagram.apis.base import BaseAPI
from instagram.models.insights import (
    AccountInsightData,
    AccountInsightMetric,
    AccountInsightPeriod,
    DemographicMetric,
    MediaInsightData,
    MediaInsightMetric,
    ReelInsightMetric,
    StoryInsightMetric,
)


class InsightsAPI(BaseAPI):
    """Read performance metrics for the account and individual media.

    Example::

        insights = await client.insights.get_account_insights(
            metrics=[AccountInsightMetric.REACH, AccountInsightMetric.VIEWS],
            period=AccountInsightPeriod.DAY,
            since=1700000000,
            until=1700086400,
        )
        for entry in insights.data:
            print(entry.name, entry.values)
    """

    # ------------------------------------------------------------------
    # Account-level insights
    # ------------------------------------------------------------------

    async def get_account_insights(
        self,
        metrics: list[AccountInsightMetric],
        period: AccountInsightPeriod = AccountInsightPeriod.DAY,
        *,
        since: int | None = None,
        until: int | None = None,
    ) -> AccountInsightData:
        """Fetch time-series insights for the authenticated account.

        Parameters
        ----------
        metrics:
            Which metrics to retrieve.
        period:
            Aggregation period (``day``, ``week``, ``days_28``).
        since:
            Unix timestamp — start of the date range (inclusive).
        until:
            Unix timestamp — end of the date range (exclusive).
            Maximum range: 30 days.

        Returns
        -------
        AccountInsightData
            Insight entries with their values.
        """
        url = self._session.url(f"{self._session.ig_user_id}/insights")
        params: dict[str, Any] = {
            "metric": ",".join(metrics),
            "period": period.value,
        }
        if since is not None:
            params["since"] = since
        if until is not None:
            params["until"] = until

        data = await self._session.get(url, params=params)
        return AccountInsightData.model_validate(data)

    async def get_demographic_insights(
        self,
        metrics: list[DemographicMetric],
    ) -> AccountInsightData:
        """Fetch lifetime demographic insights for the authenticated account.

        Requires 100+ followers.

        Parameters
        ----------
        metrics:
            Which demographic metrics to retrieve.

        Returns
        -------
        AccountInsightData
            Insight entries with demographic breakdowns.
        """
        url = self._session.url(f"{self._session.ig_user_id}/insights")
        params: dict[str, Any] = {
            "metric": ",".join(metrics),
            "period": "lifetime",
        }
        data = await self._session.get(url, params=params)
        return AccountInsightData.model_validate(data)

    # ------------------------------------------------------------------
    # Media-level insights
    # ------------------------------------------------------------------

    async def get_media_insights(
        self,
        media_id: str,
        metrics: list[MediaInsightMetric],
    ) -> MediaInsightData:
        """Fetch insights for a single image or carousel post.

        Parameters
        ----------
        media_id:
            Instagram media ID.
        metrics:
            Which metrics to retrieve.

        Returns
        -------
        MediaInsightData
            Insight entries with their values.
        """
        url = self._session.url(f"{media_id}/insights")
        params = {"metric": ",".join(metrics)}
        data = await self._session.get(url, params=params)
        return MediaInsightData.model_validate(data)

    async def get_reel_insights(
        self,
        media_id: str,
        metrics: list[ReelInsightMetric],
    ) -> MediaInsightData:
        """Fetch insights for a single Reel.

        Parameters
        ----------
        media_id:
            Instagram media ID of the reel.
        metrics:
            Which reel metrics to retrieve.

        Returns
        -------
        MediaInsightData
            Insight entries with their values.
        """
        url = self._session.url(f"{media_id}/insights")
        params = {"metric": ",".join(metrics)}
        data = await self._session.get(url, params=params)
        return MediaInsightData.model_validate(data)

    async def get_story_insights(
        self,
        media_id: str,
        metrics: list[StoryInsightMetric],
    ) -> MediaInsightData:
        """Fetch insights for a single Story.

        Story insights are only available while the story is live (24 hours).

        Parameters
        ----------
        media_id:
            Instagram media ID of the story.
        metrics:
            Which story metrics to retrieve.

        Returns
        -------
        MediaInsightData
            Insight entries with their values.
        """
        url = self._session.url(f"{media_id}/insights")
        params = {"metric": ",".join(metrics)}
        data = await self._session.get(url, params=params)
        return MediaInsightData.model_validate(data)
