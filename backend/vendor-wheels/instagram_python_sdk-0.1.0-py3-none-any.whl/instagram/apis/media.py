"""Media API namespace.

Provides access to the authenticated user's media objects (posts, reels,
stories, and carousels) including listing, querying, and iterating.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

from instagram.apis.base import BaseAPI
from instagram.models.media import Media, MediaListResponse

# Default fields to request when listing or fetching media.
_DEFAULT_MEDIA_FIELDS = (
    "id,caption,media_type,media_url,permalink,timestamp,"
    "thumbnail_url,username,like_count,comments_count,"
    "is_shared_to_feed,media_product_type,shortcode"
)


class MediaAPI(BaseAPI):
    """Read the authenticated user's media objects.

    Example::

        response = await client.media.list_media()
        for post in response.data:
            print(post.permalink, post.like_count)
    """

    async def list_media(
        self,
        *,
        fields: str | None = None,
        limit: int | None = None,
        after: str | None = None,
        before: str | None = None,
    ) -> MediaListResponse:
        """List the authenticated user's media.

        Parameters
        ----------
        fields:
            Comma-separated media fields (defaults to common fields).
        limit:
            Number of items per page.
        after:
            Cursor for forward pagination.
        before:
            Cursor for backward pagination.

        Returns
        -------
        MediaListResponse
            Paginated list of media objects.
        """
        url = self._session.url(f"{self._session.ig_user_id}/media")
        params: dict[str, Any] = {"fields": fields or _DEFAULT_MEDIA_FIELDS}
        if limit is not None:
            params["limit"] = limit
        if after is not None:
            params["after"] = after
        if before is not None:
            params["before"] = before

        data = await self._session.get(url, params=params)
        return MediaListResponse.model_validate(data)

    async def iter_media(
        self,
        *,
        fields: str | None = None,
        limit: int | None = None,
    ) -> AsyncIterator[Media]:
        """Async generator that yields all media, following pagination cursors.

        Parameters
        ----------
        fields:
            Comma-separated media fields (defaults to common fields).
        limit:
            Number of items per page.

        Yields
        ------
        Media
            Individual media objects across all pages.
        """
        after: str | None = None
        while True:
            response = await self.list_media(fields=fields, limit=limit, after=after)
            for media in response.data:
                yield media
            if (
                response.paging is None
                or response.paging.cursors is None
                or response.paging.cursors.after is None
                or response.paging.next is None
            ):
                break
            after = response.paging.cursors.after

    async def get_media(
        self,
        media_id: str,
        *,
        fields: str | None = None,
    ) -> Media:
        """Fetch a single media object by ID.

        Parameters
        ----------
        media_id:
            Instagram media ID.
        fields:
            Comma-separated media fields (defaults to common fields).

        Returns
        -------
        Media
            The requested media object.
        """
        url = self._session.url(media_id)
        params = {"fields": fields or _DEFAULT_MEDIA_FIELDS}
        data = await self._session.get(url, params=params)
        return Media.model_validate(data)

    async def get_children(
        self,
        media_id: str,
        *,
        fields: str | None = None,
    ) -> list[Media]:
        """Fetch the children of a carousel album.

        Parameters
        ----------
        media_id:
            ID of the carousel album.
        fields:
            Comma-separated fields for child items
            (defaults to ``"id,media_type,media_url,timestamp"``).

        Returns
        -------
        list[Media]
            Child media objects in carousel order.
        """
        url = self._session.url(f"{media_id}/children")
        params = {"fields": fields or "id,media_type,media_url,timestamp"}
        data = await self._session.get(url, params=params)
        return [Media.model_validate(item) for item in data.get("data", [])]

    async def list_stories(
        self,
        *,
        fields: str | None = None,
    ) -> list[Media]:
        """List the authenticated user's currently active stories.

        Stories expire 24 hours after posting.

        Parameters
        ----------
        fields:
            Comma-separated media fields (defaults to common fields).

        Returns
        -------
        list[Media]
            Currently active story media objects.
        """
        url = self._session.url(f"{self._session.ig_user_id}/stories")
        params = {"fields": fields or _DEFAULT_MEDIA_FIELDS}
        data = await self._session.get(url, params=params)
        return [Media.model_validate(item) for item in data.get("data", [])]
