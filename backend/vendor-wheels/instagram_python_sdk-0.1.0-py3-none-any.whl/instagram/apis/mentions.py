"""Mentions API namespace.

Provides methods to retrieve media where the authenticated user is
@-mentioned in captions or photo-tagged.
"""

from __future__ import annotations

from typing import Any

from instagram.apis.base import BaseAPI
from instagram.models.media import Media
from instagram.models.mentions import MentionedMedia, MentionedMediaResponse, TaggedMediaResponse

# Default fields for mentioned media.
_DEFAULT_MENTION_FIELDS = (
    "id,caption,media_type,media_url,permalink,timestamp,username,like_count,comments_count"
)


class MentionsAPI(BaseAPI):
    """Retrieve media where the authenticated user is mentioned or tagged.

    Example::

        mentions = await client.mentions.get_mentioned_media()
        for media in mentions:
            print(media.username, media.permalink)
    """

    async def get_mentioned_media(
        self,
        *,
        fields: str | None = None,
        after: str | None = None,
        limit: int | None = None,
    ) -> list[MentionedMedia]:
        """Get media where the user is @-mentioned in the caption.

        Parameters
        ----------
        fields:
            Comma-separated media fields.
        after:
            Cursor for forward pagination.
        limit:
            Number of items per page.

        Returns
        -------
        list[MentionedMedia]
            Media objects where the user is mentioned.
        """
        url = self._session.url(f"{self._session.ig_user_id}/mentioned_media")
        params: dict[str, Any] = {
            "fields": fields or _DEFAULT_MENTION_FIELDS,
        }
        if after is not None:
            params["after"] = after
        if limit is not None:
            params["limit"] = limit

        data = await self._session.get(url, params=params)
        response = MentionedMediaResponse.model_validate(data)
        return list(response.data)

    async def get_tagged_media(
        self,
        *,
        fields: str | None = None,
        after: str | None = None,
        limit: int | None = None,
    ) -> TaggedMediaResponse:
        """Get media where the user is photo-tagged.

        Parameters
        ----------
        fields:
            Comma-separated media fields.
        after:
            Cursor for forward pagination.
        limit:
            Number of items per page.

        Returns
        -------
        TaggedMediaResponse
            Paginated list of media where the user is tagged.
        """
        url = self._session.url(f"{self._session.ig_user_id}/tags")
        params: dict[str, Any] = {
            "fields": fields or _DEFAULT_MENTION_FIELDS,
        }
        if after is not None:
            params["after"] = after
        if limit is not None:
            params["limit"] = limit

        data = await self._session.get(url, params=params)
        return TaggedMediaResponse.model_validate(data)

    async def iter_tagged_media(
        self,
        *,
        fields: str | None = None,
        limit: int | None = None,
    ) -> list[Media]:
        """Fetch all tagged media across all pages.

        Parameters
        ----------
        fields:
            Comma-separated media fields.
        limit:
            Number of items per page.

        Returns
        -------
        list[Media]
            All media where the user is photo-tagged.
        """
        all_media: list[Media] = []
        after: str | None = None
        while True:
            response = await self.get_tagged_media(
                fields=fields,
                after=after,
                limit=limit,
            )
            all_media.extend(response.data)
            if (
                response.paging is None
                or response.paging.cursors is None
                or response.paging.cursors.after is None
                or response.paging.next is None
            ):
                break
            after = response.paging.cursors.after
        return all_media
