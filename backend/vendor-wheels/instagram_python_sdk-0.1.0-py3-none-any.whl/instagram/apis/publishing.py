"""Publishing API namespace.

Provides methods to publish images, reels (video), stories, and carousel
posts via Instagram's two-step container model:

1. Create a media container (``POST /{ig-user-id}/media``).
2. Publish the container (``POST /{ig-user-id}/media_publish``).

For video/reels containers, poll ``GET /{container-id}?fields=status_code``
until the status is ``FINISHED`` before publishing.
"""

from __future__ import annotations

import asyncio
from typing import Any

from instagram.apis.base import BaseAPI
from instagram.config import DEFAULT_POLL_INTERVAL, DEFAULT_POLL_TIMEOUT
from instagram.exceptions import InstagramContainerError
from instagram.models.publishing import (
    ContainerResponse,
    ContainerStatus,
    ContainerStatusResponse,
    PublishResponse,
)


class PublishingAPI(BaseAPI):
    """Create and publish Instagram media content.

    Example — publish a single image::

        container = await client.publishing.create_image_container(
            image_url="https://example.com/photo.jpg",
            caption="Hello, Instagram!",
        )
        result = await client.publishing.publish(container.id)
        print(result.id)  # published media ID

    Example — publish a reel::

        container = await client.publishing.create_reel_container(
            video_url="https://example.com/video.mp4",
            caption="Check this out!",
        )
        await client.publishing.wait_for_container(container.id)
        result = await client.publishing.publish(container.id)
    """

    # ------------------------------------------------------------------
    # Single image
    # ------------------------------------------------------------------

    async def create_image_container(
        self,
        image_url: str,
        *,
        caption: str | None = None,
        location_id: str | None = None,
        user_tags: list[dict[str, Any]] | None = None,
        collaborators: list[str] | None = None,
    ) -> ContainerResponse:
        """Create a container for a single image post.

        Parameters
        ----------
        image_url:
            Publicly accessible URL to the image.
        caption:
            Post caption (max 2 200 characters).
        location_id:
            Facebook Page ID of a location to tag.
        user_tags:
            List of ``{"username": "...", "x": 0.5, "y": 0.5}`` dicts.
        collaborators:
            List of Instagram usernames to invite as collaborators.
        """
        params: dict[str, Any] = {"image_url": image_url}
        if caption is not None:
            params["caption"] = caption
        if location_id is not None:
            params["location_id"] = location_id
        if user_tags is not None:
            params["user_tags"] = user_tags
        if collaborators is not None:
            params["collaborators"] = collaborators

        url = self._session.url(f"{self._session.ig_user_id}/media")
        data = await self._session.post(url, params=params)
        return ContainerResponse.model_validate(data)

    # ------------------------------------------------------------------
    # Reels (video)
    # ------------------------------------------------------------------

    async def create_reel_container(
        self,
        video_url: str,
        *,
        caption: str | None = None,
        share_to_feed: bool | None = None,
        location_id: str | None = None,
        thumb_offset: int | None = None,
        cover_url: str | None = None,
        collaborators: list[str] | None = None,
        audio_name: str | None = None,
    ) -> ContainerResponse:
        """Create a container for a Reel (video post).

        Parameters
        ----------
        video_url:
            Publicly accessible URL to an MP4 video.
        caption:
            Post caption (max 2 200 characters).
        share_to_feed:
            ``True`` to show in both Feed and Reels tabs.
        location_id:
            Facebook Page ID of a location to tag.
        thumb_offset:
            Millisecond offset for the auto-generated thumbnail frame.
        cover_url:
            Public URL to a custom cover image.
        collaborators:
            List of Instagram usernames to invite as collaborators.
        audio_name:
            Custom name for the reel's audio.
        """
        params: dict[str, Any] = {
            "media_type": "REELS",
            "video_url": video_url,
        }
        if caption is not None:
            params["caption"] = caption
        if share_to_feed is not None:
            params["share_to_feed"] = share_to_feed
        if location_id is not None:
            params["location_id"] = location_id
        if thumb_offset is not None:
            params["thumb_offset"] = thumb_offset
        if cover_url is not None:
            params["cover_url"] = cover_url
        if collaborators is not None:
            params["collaborators"] = collaborators
        if audio_name is not None:
            params["audio_name"] = audio_name

        url = self._session.url(f"{self._session.ig_user_id}/media")
        data = await self._session.post(url, params=params)
        return ContainerResponse.model_validate(data)

    # ------------------------------------------------------------------
    # Stories
    # ------------------------------------------------------------------

    async def create_story_image_container(
        self,
        image_url: str,
    ) -> ContainerResponse:
        """Create a container for an image story.

        Parameters
        ----------
        image_url:
            Publicly accessible URL to the image.
        """
        params: dict[str, Any] = {
            "media_type": "STORIES",
            "image_url": image_url,
        }
        url = self._session.url(f"{self._session.ig_user_id}/media")
        data = await self._session.post(url, params=params)
        return ContainerResponse.model_validate(data)

    async def create_story_video_container(
        self,
        video_url: str,
    ) -> ContainerResponse:
        """Create a container for a video story.

        Parameters
        ----------
        video_url:
            Publicly accessible URL to the video.
        """
        params: dict[str, Any] = {
            "media_type": "STORIES",
            "video_url": video_url,
        }
        url = self._session.url(f"{self._session.ig_user_id}/media")
        data = await self._session.post(url, params=params)
        return ContainerResponse.model_validate(data)

    # ------------------------------------------------------------------
    # Carousel
    # ------------------------------------------------------------------

    async def create_carousel_item_container(
        self,
        *,
        image_url: str | None = None,
        video_url: str | None = None,
    ) -> ContainerResponse:
        """Create a child container for a carousel post.

        Provide exactly one of ``image_url`` or ``video_url``.

        Parameters
        ----------
        image_url:
            Publicly accessible URL to an image.
        video_url:
            Publicly accessible URL to a video.
        """
        if (image_url is None) == (video_url is None):
            msg = "Provide exactly one of image_url or video_url."
            raise ValueError(msg)

        params: dict[str, Any] = {"is_carousel_item": "true"}
        if image_url is not None:
            params["image_url"] = image_url
        else:
            params["media_type"] = "VIDEO"
            params["video_url"] = video_url

        url = self._session.url(f"{self._session.ig_user_id}/media")
        data = await self._session.post(url, params=params)
        return ContainerResponse.model_validate(data)

    async def create_carousel_container(
        self,
        children: list[str],
        *,
        caption: str | None = None,
        location_id: str | None = None,
        collaborators: list[str] | None = None,
    ) -> ContainerResponse:
        """Create a parent carousel container from child container IDs.

        Parameters
        ----------
        children:
            List of 2-10 child container IDs created with
            :meth:`create_carousel_item_container`.
        caption:
            Post caption (max 2 200 characters).
        location_id:
            Facebook Page ID of a location to tag.
        collaborators:
            List of Instagram usernames to invite as collaborators.
        """
        if len(children) < 2 or len(children) > 10:
            msg = f"Carousels require 2-10 children, got {len(children)}."
            raise ValueError(msg)

        params: dict[str, Any] = {
            "media_type": "CAROUSEL",
            "children": ",".join(children),
        }
        if caption is not None:
            params["caption"] = caption
        if location_id is not None:
            params["location_id"] = location_id
        if collaborators is not None:
            params["collaborators"] = collaborators

        url = self._session.url(f"{self._session.ig_user_id}/media")
        data = await self._session.post(url, params=params)
        return ContainerResponse.model_validate(data)

    # ------------------------------------------------------------------
    # Container status & publishing
    # ------------------------------------------------------------------

    async def get_container_status(
        self,
        container_id: str,
    ) -> ContainerStatusResponse:
        """Check the processing status of a media container.

        Parameters
        ----------
        container_id:
            Container ID returned by a ``create_*_container`` method.
        """
        url = self._session.url(container_id)
        params = {"fields": "id,status_code,status"}
        data = await self._session.get(url, params=params)
        return ContainerStatusResponse.model_validate(data)

    async def wait_for_container(
        self,
        container_id: str,
        *,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        timeout: float = DEFAULT_POLL_TIMEOUT,
    ) -> ContainerStatusResponse:
        """Poll a container until it reaches a terminal status.

        Parameters
        ----------
        container_id:
            Container ID to poll.
        poll_interval:
            Seconds between poll attempts (default: 3.0).
        timeout:
            Maximum total wait time in seconds (default: 300.0).

        Returns
        -------
        ContainerStatusResponse
            Final container status (``FINISHED`` or ``ERROR``).

        Raises
        ------
        InstagramContainerError
            If the container reaches ``ERROR`` or ``EXPIRED`` status.
        TimeoutError
            If the container does not reach a terminal state within *timeout*.
        """
        elapsed = 0.0
        while elapsed < timeout:
            status = await self.get_container_status(container_id)

            if status.status_code == ContainerStatus.FINISHED:
                return status

            if status.status_code in (ContainerStatus.ERROR, ContainerStatus.EXPIRED):
                raise InstagramContainerError(
                    f"Container {container_id} failed: {status.status or status.status_code}",
                    status_code=status.status_code.value if status.status_code else None,
                )

            await asyncio.sleep(poll_interval)
            elapsed += poll_interval

        raise TimeoutError(f"Container {container_id} did not finish within {timeout}s")

    async def publish(
        self,
        container_id: str,
    ) -> PublishResponse:
        """Publish a finished media container.

        Parameters
        ----------
        container_id:
            Container ID that has reached ``FINISHED`` status.

        Returns
        -------
        PublishResponse
            Contains the published media ID.
        """
        url = self._session.url(f"{self._session.ig_user_id}/media_publish")
        params = {"creation_id": container_id}
        data = await self._session.post(url, params=params)
        return PublishResponse.model_validate(data)

    # ------------------------------------------------------------------
    # High-level convenience methods
    # ------------------------------------------------------------------

    async def publish_image(
        self,
        image_url: str,
        *,
        caption: str | None = None,
        location_id: str | None = None,
        user_tags: list[dict[str, Any]] | None = None,
        collaborators: list[str] | None = None,
    ) -> PublishResponse:
        """Create and immediately publish a single image post.

        This is a convenience method that combines
        :meth:`create_image_container` and :meth:`publish`.
        """
        container = await self.create_image_container(
            image_url,
            caption=caption,
            location_id=location_id,
            user_tags=user_tags,
            collaborators=collaborators,
        )
        return await self.publish(container.id)

    async def publish_reel(
        self,
        video_url: str,
        *,
        caption: str | None = None,
        share_to_feed: bool | None = None,
        location_id: str | None = None,
        thumb_offset: int | None = None,
        cover_url: str | None = None,
        collaborators: list[str] | None = None,
        audio_name: str | None = None,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        poll_timeout: float = DEFAULT_POLL_TIMEOUT,
    ) -> PublishResponse:
        """Create, wait for processing, and publish a Reel.

        This is a convenience method that combines
        :meth:`create_reel_container`, :meth:`wait_for_container`, and
        :meth:`publish`.
        """
        container = await self.create_reel_container(
            video_url,
            caption=caption,
            share_to_feed=share_to_feed,
            location_id=location_id,
            thumb_offset=thumb_offset,
            cover_url=cover_url,
            collaborators=collaborators,
            audio_name=audio_name,
        )
        await self.wait_for_container(
            container.id,
            poll_interval=poll_interval,
            timeout=poll_timeout,
        )
        return await self.publish(container.id)

    async def publish_story_image(
        self,
        image_url: str,
    ) -> PublishResponse:
        """Create and immediately publish an image story."""
        container = await self.create_story_image_container(image_url)
        return await self.publish(container.id)

    async def publish_story_video(
        self,
        video_url: str,
        *,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        poll_timeout: float = DEFAULT_POLL_TIMEOUT,
    ) -> PublishResponse:
        """Create, wait for processing, and publish a video story."""
        container = await self.create_story_video_container(video_url)
        await self.wait_for_container(
            container.id,
            poll_interval=poll_interval,
            timeout=poll_timeout,
        )
        return await self.publish(container.id)

    async def publish_carousel(
        self,
        items: list[dict[str, str]],
        *,
        caption: str | None = None,
        location_id: str | None = None,
        collaborators: list[str] | None = None,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        poll_timeout: float = DEFAULT_POLL_TIMEOUT,
    ) -> PublishResponse:
        """Create and publish a carousel post in one call.

        Parameters
        ----------
        items:
            List of dicts, each with either ``{"image_url": "..."}`` or
            ``{"video_url": "..."}``.
        caption:
            Post caption (max 2 200 characters).
        location_id:
            Facebook Page ID of a location to tag.
        collaborators:
            List of Instagram usernames to invite as collaborators.
        poll_interval:
            Seconds between status polls for video children.
        poll_timeout:
            Maximum wait time for video children processing.
        """
        child_ids: list[str] = []
        for item in items:
            child = await self.create_carousel_item_container(
                image_url=item.get("image_url"),
                video_url=item.get("video_url"),
            )
            # Video children need processing time.
            if "video_url" in item:
                await self.wait_for_container(
                    child.id,
                    poll_interval=poll_interval,
                    timeout=poll_timeout,
                )
            child_ids.append(child.id)

        container = await self.create_carousel_container(
            child_ids,
            caption=caption,
            location_id=location_id,
            collaborators=collaborators,
        )
        return await self.publish(container.id)
