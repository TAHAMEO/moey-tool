"""Main entry point for the Instagram Python SDK.

Usage — async context manager (recommended)::

    async with InstagramClient(
        access_token="YOUR_TOKEN",
        ig_user_id="17841405822304914",
    ) as client:
        user = await client.account.get_profile(
            fields=[AccountField.USERNAME, AccountField.FOLLOWERS_COUNT]
        )
        print(user.username, user.followers_count)

Usage — manual lifecycle management::

    client = InstagramClient(access_token="YOUR_TOKEN", ig_user_id="17841...")
    try:
        media = await client.media.list_media()
    finally:
        await client.aclose()
"""

from __future__ import annotations

from types import TracebackType
from typing import Self

from instagram.apis.account import AccountAPI
from instagram.apis.comments import CommentsAPI
from instagram.apis.hashtags import HashtagsAPI
from instagram.apis.insights import InsightsAPI
from instagram.apis.media import MediaAPI
from instagram.apis.mentions import MentionsAPI
from instagram.apis.publishing import PublishingAPI
from instagram.config import (
    DEFAULT_TIMEOUT,
    INSTAGRAM_API_VERSION,
    INSTAGRAM_GRAPH_API_BASE_URL,
)
from instagram.exceptions import InstagramConfigError
from instagram.http.session import InstagramSession


class InstagramClient:
    """Async Instagram Graph API client.

    Instantiate with a valid access token and your Instagram Business or
    Creator account ID.  The SDK does **not** handle OAuth itself; token
    management must be handled externally.

    Parameters
    ----------
    access_token:
        Instagram / Meta access token (long-lived or short-lived).
    ig_user_id:
        The Instagram Business or Creator account ID (numeric string).
    base_url:
        Graph API host (default: ``https://graph.instagram.com``).
        Override to ``https://graph.facebook.com`` when using Facebook
        Login tokens.
    api_version:
        Graph API version string (default: ``v22.0``).
    timeout:
        Total HTTP request timeout in seconds (default: ``30.0``).

    Attributes
    ----------
    account:    :class:`~instagram.apis.account.AccountAPI`
    media:      :class:`~instagram.apis.media.MediaAPI`
    publishing: :class:`~instagram.apis.publishing.PublishingAPI`
    insights:   :class:`~instagram.apis.insights.InsightsAPI`
    comments:   :class:`~instagram.apis.comments.CommentsAPI`
    hashtags:   :class:`~instagram.apis.hashtags.HashtagsAPI`
    mentions:   :class:`~instagram.apis.mentions.MentionsAPI`
    """

    def __init__(
        self,
        access_token: str,
        ig_user_id: str,
        *,
        base_url: str = INSTAGRAM_GRAPH_API_BASE_URL,
        api_version: str = INSTAGRAM_API_VERSION,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        if not access_token:
            raise InstagramConfigError("access_token must not be empty.")
        if not ig_user_id:
            raise InstagramConfigError("ig_user_id must not be empty.")

        self._session = InstagramSession(
            access_token=access_token,
            ig_user_id=ig_user_id,
            base_url=base_url,
            api_version=api_version,
            timeout=timeout,
        )

        self.account = AccountAPI(self._session)
        self.media = MediaAPI(self._session)
        self.publishing = PublishingAPI(self._session)
        self.insights = InsightsAPI(self._session)
        self.comments = CommentsAPI(self._session)
        self.hashtags = HashtagsAPI(self._session)
        self.mentions = MentionsAPI(self._session)

    # ------------------------------------------------------------------
    # Context manager support
    # ------------------------------------------------------------------

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.aclose()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def aclose(self) -> None:
        """Close the underlying HTTP session and release all connections.

        Call this when you are done with the client if you are **not** using
        it as an async context manager.
        """
        await self._session.aclose()
