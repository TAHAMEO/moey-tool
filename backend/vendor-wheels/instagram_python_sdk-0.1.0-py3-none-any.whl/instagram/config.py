"""SDK-wide constants and configuration defaults."""

# Instagram Graph API base URL.
# Uses the Instagram Platform API host (graph.instagram.com).
# Callers using legacy Facebook Login tokens should override via
# ``InstagramClient(base_url="https://graph.facebook.com")``.
INSTAGRAM_GRAPH_API_BASE_URL = "https://graph.instagram.com"

# Current Graph API version.
INSTAGRAM_API_VERSION = "v22.0"

# Default network timeout in seconds for API requests.
DEFAULT_TIMEOUT: float = 30.0

# Maximum number of items returned per page by the media list endpoint.
MEDIA_LIST_DEFAULT_LIMIT: int = 25

# Maximum number of carousel children allowed per post.
CAROUSEL_MAX_CHILDREN: int = 10

# Minimum number of carousel children required per post.
CAROUSEL_MIN_CHILDREN: int = 2

# Maximum caption length (characters).
MAX_CAPTION_LENGTH: int = 2200

# Maximum hashtags per caption.
MAX_CAPTION_HASHTAGS: int = 30

# Publishing rate limit — posts per 24-hour rolling window.
PUBLISH_RATE_LIMIT_24H: int = 25

# Hashtag search limit — unique queries per 7-day rolling window.
HASHTAG_SEARCH_LIMIT_7D: int = 30

# Container time-to-live — seconds before an unpublished container expires.
CONTAINER_TTL_SECONDS: int = 86400  # 24 hours

# Poll interval (seconds) used by wait_for_container.
DEFAULT_POLL_INTERVAL: float = 3.0

# Maximum total wait time (seconds) used by wait_for_container.
DEFAULT_POLL_TIMEOUT: float = 300.0
