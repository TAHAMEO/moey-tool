"""Exception hierarchy for the Instagram Python SDK.

All exceptions raised by the SDK derive from ``InstagramSDKError`` so callers
can catch the entire family with a single ``except`` clause when needed.
"""

from __future__ import annotations


class InstagramSDKError(Exception):
    """Base class for every exception raised by this SDK."""


# ---------------------------------------------------------------------------
# API-level errors (the Instagram Graph API returned an error payload)
# ---------------------------------------------------------------------------


class InstagramAPIError(InstagramSDKError):
    """The Instagram Graph API responded with an error.

    Attributes:
        code:        Numeric error code from the API (e.g. ``190``).
        error_type:  Error type string (e.g. ``"OAuthException"``).
        message:     Human-readable description from the API.
        fbtrace_id:  Opaque request identifier useful for support tickets.
        http_status: HTTP status code of the underlying response.
        error_subcode: Optional sub-code providing more detail.
    """

    def __init__(
        self,
        code: int,
        error_type: str,
        message: str,
        fbtrace_id: str,
        http_status: int = 400,
        error_subcode: int | None = None,
    ) -> None:
        self.code = code
        self.error_type = error_type
        self.message = message
        self.fbtrace_id = fbtrace_id
        self.http_status = http_status
        self.error_subcode = error_subcode
        super().__init__(f"[{code}] {message} (type={error_type}, fbtrace_id={fbtrace_id})")


class InstagramAuthError(InstagramAPIError):
    """Raised when the access token is missing, invalid, expired, or lacks required permissions."""


class InstagramRateLimitError(InstagramAPIError):
    """Raised when an API rate limit has been exceeded."""


class InstagramPermissionError(InstagramAPIError):
    """Raised when the app does not have the required permission for the request."""


class InstagramNotFoundError(InstagramAPIError):
    """Raised when the requested resource does not exist."""


class InstagramServerError(InstagramAPIError):
    """Raised when the Instagram Graph API returns an internal server error."""


# ---------------------------------------------------------------------------
# Client / transport-level errors
# ---------------------------------------------------------------------------


class InstagramConfigError(InstagramSDKError):
    """Raised when the SDK client is misconfigured (e.g. missing credentials)."""


class InstagramContainerError(InstagramSDKError):
    """Raised when a media container fails to process or expires.

    Attributes:
        status_code: Container status (e.g. ``"ERROR"``, ``"EXPIRED"``).
    """

    def __init__(self, message: str, status_code: str | None = None) -> None:
        self.status_code = status_code
        super().__init__(message)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

# Mapping of Instagram error codes to specific exception subclasses.
_ERROR_CODE_MAP: dict[int, type[InstagramAPIError]] = {
    190: InstagramAuthError,  # Invalid / expired token
    200: InstagramPermissionError,  # Insufficient permissions
    10: InstagramPermissionError,  # App does not have permission
    4: InstagramRateLimitError,  # Rate limit exceeded
    17: InstagramRateLimitError,  # User request limit reached
    32: InstagramRateLimitError,  # Page request limit reached
    100: InstagramAPIError,  # Invalid parameter
    803: InstagramNotFoundError,  # Resource not found
}


def build_api_error(
    code: int,
    error_type: str,
    message: str,
    fbtrace_id: str,
    http_status: int = 400,
    error_subcode: int | None = None,
) -> InstagramAPIError:
    """Return the most specific :class:`InstagramAPIError` subclass for *code*."""
    exc_class = _ERROR_CODE_MAP.get(code, InstagramAPIError)
    if http_status >= 500 and exc_class is InstagramAPIError:
        exc_class = InstagramServerError
    return exc_class(
        code=code,
        error_type=error_type,
        message=message,
        fbtrace_id=fbtrace_id,
        http_status=http_status,
        error_subcode=error_subcode,
    )
