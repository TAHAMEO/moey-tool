"""Async HTTP session that wraps ``aiohttp`` for all Instagram Graph API communication.

Responsibilities
----------------
* Attach the access token to every request via the ``Authorization`` header.
* Deserialise JSON responses and surface Instagram error payloads as typed
  exceptions.
* Provide convenience methods for GET, POST, and DELETE requests.
"""

from __future__ import annotations

import asyncio
from typing import Any

import aiohttp

from instagram.config import DEFAULT_TIMEOUT, INSTAGRAM_API_VERSION, INSTAGRAM_GRAPH_API_BASE_URL
from instagram.exceptions import InstagramAPIError, build_api_error


class InstagramSession:
    """Thin async HTTP client bound to a single user access token.

    The underlying :class:`aiohttp.ClientSession` is created lazily on the
    first request so the object can be constructed outside a running event
    loop without triggering deprecation warnings.

    Parameters
    ----------
    access_token:
        A valid Instagram / Meta access token (long-lived or short-lived).
    ig_user_id:
        The Instagram Business or Creator account ID.
    base_url:
        Graph API host (default: ``https://graph.instagram.com``).
        Override to ``https://graph.facebook.com`` when using Facebook Login
        tokens.
    api_version:
        Graph API version string (default: ``v22.0``).
    timeout:
        Total request timeout in seconds (default: ``DEFAULT_TIMEOUT``).
    """

    def __init__(
        self,
        access_token: str,
        ig_user_id: str,
        *,
        base_url: str = INSTAGRAM_GRAPH_API_BASE_URL,
        api_version: str = INSTAGRAM_API_VERSION,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self._access_token = access_token
        self.ig_user_id = ig_user_id
        self._base_url = f"{base_url.rstrip('/')}/{api_version}"
        self._timeout = aiohttp.ClientTimeout(total=timeout)
        self._session: aiohttp.ClientSession | None = None
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # URL helpers
    # ------------------------------------------------------------------

    def url(self, path: str) -> str:
        """Build a fully-qualified URL from a relative path."""
        return f"{self._base_url}/{path.lstrip('/')}"

    # ------------------------------------------------------------------
    # Session lifecycle
    # ------------------------------------------------------------------

    async def _get_session(self) -> aiohttp.ClientSession:
        async with self._lock:
            if self._session is None or self._session.closed:
                connector = aiohttp.TCPConnector(
                    limit=100,
                    ttl_dns_cache=300,
                    ssl=True,
                )
                self._session = aiohttp.ClientSession(
                    connector=connector,
                    timeout=self._timeout,
                    headers={
                        "Authorization": f"Bearer {self._access_token}",
                    },
                )
        return self._session

    async def aclose(self) -> None:
        """Close the underlying HTTP session and release all connections."""
        async with self._lock:
            if self._session is not None and not self._session.closed:
                await self._session.close()
                self._session = None

    # ------------------------------------------------------------------
    # Public request methods
    # ------------------------------------------------------------------

    async def get(
        self,
        url: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Issue a GET request and return the parsed JSON body."""
        session = await self._get_session()
        async with session.get(url, params=params) as response:
            return await self._parse_json_response(response)

    async def post(
        self,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Issue a POST request and return the parsed JSON body."""
        session = await self._get_session()
        async with session.post(url, params=params, json=json) as response:
            return await self._parse_json_response(response)

    async def delete(
        self,
        url: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Issue a DELETE request and return the parsed JSON body."""
        session = await self._get_session()
        async with session.delete(url, params=params) as response:
            return await self._parse_json_response(response)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    async def _parse_json_response(response: aiohttp.ClientResponse) -> dict[str, Any]:
        """Parse an Instagram Graph API JSON response, raising on errors.

        The Instagram Graph API returns errors in the following format::

            {
                "error": {
                    "message": "...",
                    "type": "OAuthException",
                    "code": 190,
                    "error_subcode": 460,
                    "fbtrace_id": "AbCdEfGhIjK"
                }
            }

        When the response contains an ``error`` key the call failed, and we
        map it to the most specific exception subclass.
        """
        raw_body = await response.read()
        if not raw_body or not raw_body.strip():
            raise InstagramAPIError(
                code=0,
                error_type="EmptyResponse",
                message=(
                    f"Instagram returned an empty response body "
                    f"(HTTP {response.status}, url={response.url})"
                ),
                fbtrace_id="",
                http_status=response.status,
            )

        payload: dict[str, Any] = await response.json(content_type=None)
        error: dict[str, Any] | None = payload.get("error")

        if error is not None:
            raise build_api_error(
                code=error.get("code", 0),
                error_type=error.get("type", "UnknownError"),
                message=error.get("message", ""),
                fbtrace_id=error.get("fbtrace_id", ""),
                http_status=response.status,
                error_subcode=error.get("error_subcode"),
            )

        return payload
