"""Pydantic models for Instagram account / user profile data."""

from __future__ import annotations

from enum import StrEnum

from instagram.models.base import InstagramBaseModel


class AccountField(StrEnum):
    """Queryable fields on the Instagram user profile endpoint.

    Pass a list of these to :meth:`AccountAPI.get_profile` to control which
    fields are returned.
    """

    ID = "id"
    USERNAME = "username"
    NAME = "name"
    BIOGRAPHY = "biography"
    FOLLOWERS_COUNT = "followers_count"
    FOLLOWS_COUNT = "follows_count"
    MEDIA_COUNT = "media_count"
    PROFILE_PICTURE_URL = "profile_picture_url"
    WEBSITE = "website"
    IG_ID = "ig_id"
    ACCOUNT_TYPE = "account_type"


class User(InstagramBaseModel):
    """Instagram user profile.

    Only the fields explicitly requested via ``AccountField`` will be
    populated; all others will be ``None``.
    """

    id: str | None = None
    username: str | None = None
    name: str | None = None
    biography: str | None = None
    followers_count: int | None = None
    follows_count: int | None = None
    media_count: int | None = None
    profile_picture_url: str | None = None
    website: str | None = None
    ig_id: int | None = None
    account_type: str | None = None


class BusinessDiscoveryUser(InstagramBaseModel):
    """Public profile data returned by the business discovery endpoint.

    Contains the same fields as :class:`User` but may also include a
    nested ``media`` list when requested.
    """

    id: str | None = None
    username: str | None = None
    name: str | None = None
    biography: str | None = None
    followers_count: int | None = None
    follows_count: int | None = None
    media_count: int | None = None
    profile_picture_url: str | None = None
    website: str | None = None
