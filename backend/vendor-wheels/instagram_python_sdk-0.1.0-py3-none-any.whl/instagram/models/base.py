"""Shared base types used across all Instagram API response models."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class InstagramError(BaseModel):
    """Error object returned by the Instagram Graph API.

    Attributes:
        message:       Human-readable description of the error.
        type:          Error type string (e.g. ``"OAuthException"``).
        code:          Numeric error code.
        error_subcode: Optional sub-code with more detail.
        fbtrace_id:    Opaque request identifier for support / debugging.
    """

    model_config = ConfigDict(frozen=True)

    message: str
    type: str
    code: int
    error_subcode: int | None = None
    fbtrace_id: str = ""


class InstagramBaseModel(BaseModel):
    """Base class for all SDK response models.

    All response models inherit from this class so that unknown fields
    returned by future API versions are silently ignored rather than
    causing validation failures.
    """

    model_config = ConfigDict(
        frozen=True,
        extra="ignore",
        populate_by_name=True,
    )


class PagingCursors(InstagramBaseModel):
    """Cursor pair for pagination."""

    before: str | None = None
    after: str | None = None


class CursorPaging(InstagramBaseModel):
    """Cursor-based pagination metadata returned by list endpoints."""

    cursors: PagingCursors | None = None
    next: str | None = None
    previous: str | None = None
