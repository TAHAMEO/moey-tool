"""Pydantic models for Instagram comments."""

from __future__ import annotations

from pydantic import Field

from instagram.models.base import CursorPaging, InstagramBaseModel


class Comment(InstagramBaseModel):
    """An Instagram comment or reply.

    Attributes:
        id:         Comment ID.
        text:       Comment body text.
        timestamp:  ISO-8601 creation timestamp.
        username:   Username of the commenter.
        like_count: Number of likes on the comment.
        replies:    Nested replies (only one level deep on Instagram).
    """

    id: str | None = None
    text: str | None = None
    timestamp: str | None = None
    username: str | None = None
    like_count: int | None = None
    replies: CommentListResponse | None = None


class CommentListResponse(InstagramBaseModel):
    """Paginated list of comments."""

    data: list[Comment] = Field(default_factory=list)
    paging: CursorPaging | None = None
