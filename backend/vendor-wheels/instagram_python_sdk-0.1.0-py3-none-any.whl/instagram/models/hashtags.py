"""Pydantic models for Instagram hashtag search and discovery."""

from __future__ import annotations

from pydantic import Field

from instagram.models.base import CursorPaging, InstagramBaseModel
from instagram.models.media import Media


class Hashtag(InstagramBaseModel):
    """A hashtag with its Instagram ID.

    Attributes:
        id:   Hashtag node ID (use with top/recent media endpoints).
        name: Hashtag text without the ``#`` prefix.
    """

    id: str
    name: str | None = None


class HashtagSearchResponse(InstagramBaseModel):
    """Response from the hashtag search endpoint."""

    data: list[Hashtag] = Field(default_factory=list)


class HashtagMediaResponse(InstagramBaseModel):
    """Paginated list of media for a hashtag (top or recent)."""

    data: list[Media] = Field(default_factory=list)
    paging: CursorPaging | None = None
