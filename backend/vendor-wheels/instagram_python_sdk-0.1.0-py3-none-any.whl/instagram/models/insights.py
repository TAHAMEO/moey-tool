"""Pydantic models for Instagram insights / analytics."""

from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import Field

from instagram.models.base import InstagramBaseModel

# ---------------------------------------------------------------------------
# Account-level insight enums
# ---------------------------------------------------------------------------


class AccountInsightMetric(StrEnum):
    """Time-series metrics available on the account insights endpoint.

    Use with ``period="day"`` unless otherwise noted.
    """

    REACH = "reach"
    FOLLOWER_COUNT = "follower_count"
    VIEWS = "views"


class DemographicMetric(StrEnum):
    """Lifetime / demographic metrics (period must be ``lifetime``).

    Require 100+ followers to return data.
    """

    AUDIENCE_GENDER_AGE = "audience_gender_age"
    AUDIENCE_LOCALE = "audience_locale"
    AUDIENCE_COUNTRY = "audience_country"
    AUDIENCE_CITY = "audience_city"
    ONLINE_FOLLOWERS = "online_followers"


class AccountInsightPeriod(StrEnum):
    """Allowed time periods for account insights."""

    DAY = "day"
    WEEK = "week"
    DAYS_28 = "days_28"
    LIFETIME = "lifetime"


# ---------------------------------------------------------------------------
# Media-level insight enums
# ---------------------------------------------------------------------------


class MediaInsightMetric(StrEnum):
    """Metrics available for image and carousel media insights."""

    REACH = "reach"
    SAVED = "saved"
    VIEWS = "views"
    LIKES = "likes"
    COMMENTS = "comments"
    SHARES = "shares"
    TOTAL_INTERACTIONS = "total_interactions"
    PROFILE_VISITS = "profile_visits"
    FOLLOWS = "follows"


class ReelInsightMetric(StrEnum):
    """Metrics available for Reels insights."""

    REACH = "reach"
    SAVED = "saved"
    VIEWS = "views"
    LIKES = "likes"
    COMMENTS = "comments"
    SHARES = "shares"
    TOTAL_INTERACTIONS = "total_interactions"


class StoryInsightMetric(StrEnum):
    """Metrics available for Story insights (24-hour window)."""

    REACH = "reach"
    EXITS = "exits"
    REPLIES = "replies"
    TAPS_FORWARD = "taps_forward"
    TAPS_BACK = "taps_back"
    VIEWS = "views"
    SHARES = "shares"


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class InsightValue(InstagramBaseModel):
    """A single data point within an insight metric.

    Attributes:
        value:    The metric value -- may be an int, float, or dict
                  (for demographic breakdowns).
        end_time: ISO-8601 timestamp marking the end of the period
                  (only present for time-series metrics).
    """

    value: Any = None
    end_time: str | None = None


class InsightEntry(InstagramBaseModel):
    """A single insight metric with its name, period, and data values."""

    name: str
    period: str
    title: str | None = None
    description: str | None = None
    id: str | None = None
    values: list[InsightValue] = Field(default_factory=list)


class AccountInsightData(InstagramBaseModel):
    """Response wrapper for account-level insights."""

    data: list[InsightEntry] = Field(default_factory=list)


class MediaInsightData(InstagramBaseModel):
    """Response wrapper for media-level insights."""

    data: list[InsightEntry] = Field(default_factory=list)
