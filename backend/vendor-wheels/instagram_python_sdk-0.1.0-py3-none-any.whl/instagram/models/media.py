"""Pydantic models for Instagram media objects."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field

from instagram.models.base import CursorPaging, InstagramBaseModel


class MediaType(StrEnum):
    """Instagram media types."""

    IMAGE = "IMAGE"
    VIDEO = "VIDEO"
    CAROUSEL_ALBUM = "CAROUSEL_ALBUM"


class MediaProductType(StrEnum):
    """Product type indicating how media is surfaced on Instagram."""

    FEED = "FEED"
    REELS = "REELS"
    STORY = "STORY"


class Media(InstagramBaseModel):
    """A single Instagram media object (post, reel, story, or carousel).

    Only the fields explicitly requested will be populated; all others
    will be ``None``.
    """

    id: str | None = None
    caption: str | None = None
    media_type: MediaType | None = None
    media_url: str | None = None
    permalink: str | None = None
    timestamp: str | None = None
    thumbnail_url: str | None = None
    username: str | None = None
    like_count: int | None = None
    comments_count: int | None = None
    is_shared_to_feed: bool | None = None
    media_product_type: MediaProductType | None = None
    shortcode: str | None = None
    children: list[Media] | None = None


class MediaListResponse(InstagramBaseModel):
    """Paginated list of media returned by the user media endpoint."""

    data: list[Media] = Field(default_factory=list)
    paging: CursorPaging | None = None
