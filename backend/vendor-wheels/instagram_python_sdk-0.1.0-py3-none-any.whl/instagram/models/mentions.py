"""Pydantic models for Instagram mentions and tagged media."""

from __future__ import annotations

from pydantic import Field

from instagram.models.base import CursorPaging, InstagramBaseModel
from instagram.models.media import Media


class MentionedMedia(InstagramBaseModel):
    """Media object where the authenticated user was @-mentioned in the caption."""

    id: str | None = None
    caption: str | None = None
    media_type: str | None = None
    media_url: str | None = None
    permalink: str | None = None
    timestamp: str | None = None
    username: str | None = None
    like_count: int | None = None
    comments_count: int | None = None


class MentionedMediaResponse(InstagramBaseModel):
    """Response wrapper for the mentioned-media endpoint."""

    data: list[MentionedMedia] = Field(default_factory=list)
    paging: CursorPaging | None = None


class TaggedMediaResponse(InstagramBaseModel):
    """Paginated list of media the user is photo-tagged in."""

    data: list[Media] = Field(default_factory=list)
    paging: CursorPaging | None = None
