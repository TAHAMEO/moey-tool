"""Pydantic models for Instagram content publishing."""

from __future__ import annotations

from enum import StrEnum

from instagram.models.base import InstagramBaseModel


class ContainerStatus(StrEnum):
    """Status codes for a media container during processing."""

    EXPIRED = "EXPIRED"
    ERROR = "ERROR"
    FINISHED = "FINISHED"
    IN_PROGRESS = "IN_PROGRESS"


class ContainerResponse(InstagramBaseModel):
    """Response from creating a media container.

    Attributes:
        id: The container ID to be used with ``media_publish`` or to poll status.
    """

    id: str


class ContainerStatusResponse(InstagramBaseModel):
    """Response when checking the status of a media container.

    Attributes:
        id:          Container ID.
        status_code: Current processing status.
        status:      Error details when ``status_code`` is ``ERROR``.
    """

    id: str | None = None
    status_code: ContainerStatus | None = None
    status: str | None = None


class PublishResponse(InstagramBaseModel):
    """Response from publishing a media container.

    Attributes:
        id: The published media ID.
    """

    id: str
